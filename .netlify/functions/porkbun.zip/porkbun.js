var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var porkbun_exports = {};
__export(porkbun_exports, {
  createApexRecords: () => createApexRecords,
  createCnameRecord: () => createCnameRecord,
  createDnsRecord: () => createDnsRecord,
  listAllDomains: () => listAllDomains,
  ping: () => ping
});
module.exports = __toCommonJS(porkbun_exports);
const API_BASE = "https://api.porkbun.com/api/json/v3";
function getCredentials() {
  const apiKey = process.env.PORKBUN_API_KEY;
  const secretKey = process.env.PORKBUN_SECRET_API_KEY;
  if (!apiKey || !secretKey) return null;
  return { apikey: apiKey, secretapikey: secretKey };
}
async function porkbunPost(endpoint, body = {}) {
  const creds = getCredentials();
  if (!creds) throw new Error("Porkbun API keys not configured");
  const res = await fetch(`${API_BASE}${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...creds, ...body })
  });
  const data = await res.json().catch(() => ({}));
  if (data.status === "ERROR") throw new Error(data.message || "Porkbun API error");
  if (!res.ok) throw new Error(data.message || `HTTP ${res.status}`);
  return data;
}
async function createDnsRecord(domain, record) {
  const { name, type, content, ttl = 600 } = record;
  const data = await porkbunPost(`/dns/create/${domain}`, {
    name: name || "",
    type,
    content,
    ttl: String(ttl)
  });
  return { id: data.id };
}
async function createCnameRecord(subdomain, rootDomain, target) {
  return createDnsRecord(rootDomain, {
    name: subdomain,
    type: "CNAME",
    content: target,
    ttl: 600
  });
}
async function createApexRecords(rootDomain) {
  const lbIp = "75.2.60.5";
  const res = await porkbunPost(`/dns/create/${rootDomain}`, {
    name: "",
    type: "A",
    content: lbIp,
    ttl: 600
  });
  return { id: res.id };
}
async function ping() {
  const data = await porkbunPost("/ping");
  return { yourIp: data.yourIp };
}
async function listAllDomains() {
  const allDomains = [];
  let start = 0;
  while (true) {
    const data = await porkbunPost("/domain/listAll", { start: String(start) });
    const page = data.domains || [];
    allDomains.push(...page);
    if (page.length < 1e3) break;
    start += 1e3;
  }
  return allDomains.map((d) => ({
    domain: d.domain,
    status: d.status,
    tld: d.tld,
    createDate: d.createDate,
    expireDate: d.expireDate,
    autoRenew: d.autoRenew
  }));
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createApexRecords,
  createCnameRecord,
  createDnsRecord,
  listAllDomains,
  ping
});
