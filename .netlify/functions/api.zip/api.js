import express from 'express';
import cors from 'cors';
import { PrismaClient } from '@prisma/client';
import serverless from 'serverless-http';
import { nanoid } from 'nanoid';
import { UAParser } from 'ua-parser-js';
import crypto from 'crypto';
import { createCnameRecord, listAllDomains } from './porkbun.js';
import { isVpnOrDatacenter } from './vpn-lists.js';
import { analyzeIpAdvanced } from './ultraIpDetection.js';

// Cache for OG tags (5 minutes)
const ogCache = new Map();
const OG_CACHE_TTL = 5 * 60 * 1000;

// Reverse geocode GPS coordinates to street address using OSM Nominatim (free, no key)
async function reverseGeocode(lat, lon) {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`;
    const res = await fetch(url, {
      headers: { 'User-Agent': 'TraceLink/2033 (contact@thr0ne.com)', 'Accept-Language': 'en' },
      signal: AbortSignal.timeout(4000)
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (!data || !data.address) return null;
    const a = data.address;
    const parts = [
      a.house_number && a.road ? `${a.house_number} ${a.road}` : (a.road || a.pedestrian || a.footway),
      a.suburb || a.neighbourhood || a.quarter,
      a.city || a.town || a.village || a.municipality,
      a.state || a.county,
      a.postcode,
      a.country
    ].filter(Boolean);
    return parts.join(', ') || data.display_name || null;
  } catch (e) {
    return null;
  }
}

// Fetch OG tags from destination URL
async function fetchOgTags(url) {
  try {
    // Check cache
    const cached = ogCache.get(url);
    if (cached && Date.now() - cached.timestamp < OG_CACHE_TTL) {
      return cached.data;
    }

    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      },
      signal: AbortSignal.timeout(5000)
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const html = await response.text();

    // Parse OG tags
    const ogTags = {
      title: extractMetaTag(html, 'og:title') || extractTitle(html) || 'Link Preview',
      description: extractMetaTag(html, 'og:description') || extractMetaTag(html, 'description') || 'Click to view the shared content',
      image: extractMetaTag(html, 'og:image') || extractMetaTag(html, 'twitter:image') || extractFirstImage(html),
      siteName: extractMetaTag(html, 'og:site_name') || new URL(url).hostname,
      themeColor: extractMetaTag(html, 'theme-color'),
      favicon: extractLinkTag(html, 'icon') || extractLinkTag(html, 'shortcut icon')
    };

    // Cache result
    ogCache.set(url, { data: ogTags, timestamp: Date.now() });

    return ogTags;
  } catch (error) {
    console.error('OG fetch error:', error.message);
    // Return fallback
    try {
      const urlObj = new URL(url);
      return {
        title: `Link from ${urlObj.hostname}`,
        description: `Click to visit ${urlObj.hostname}`,
        image: null,
        siteName: urlObj.hostname
      };
    } catch {
      return {
        title: 'Link Preview',
        description: 'Click to view the shared content',
        image: null,
        siteName: 'thr0ne.com'
      };
    }
  }
}

function extractMetaTag(html, property) {
  // Regex to match both <meta property="prop" content="val"> AND <meta content="val" property="prop">
  const regex = new RegExp(`<meta\\s+(?:[^>]*?\\s+)?(?:property|name)=["']${property}["'][^>]*>`, 'i');
  const tagMatch = html.match(regex);
  if (!tagMatch) return null;

  const contentRegex = /content=["']([^"']+)["']/i;
  const contentMatch = tagMatch[0].match(contentRegex);
  return contentMatch ? contentMatch[1] : null;
}

function extractLinkTag(html, rel) {
  const regex = new RegExp(`<link\\s+(?:[^>]*?\\s+)?rel=["']${rel}["'][^>]*>`, 'i');
  const tagMatch = html.match(regex);
  if (!tagMatch) return null;

  const hrefRegex = /href=["']([^"']+)["']/i;
  const hrefMatch = tagMatch[0].match(hrefRegex);
  return hrefMatch ? hrefMatch[1] : null;
}

function extractTitle(html) {
  const match = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  return match ? match[1].trim() : null;
}

function extractFirstImage(html) {
  const match = html.match(/<img[^>]+src=["'](https?:\/\/[^"']+)["']/i);
  return match ? match[1] : null;
}

let prisma = null;
let app = null;

function getPrisma() {
  if (!prisma) {
    prisma = new PrismaClient({
      log: ['error'],
    });
  }
  return prisma;
}

function getApp() {
  if (app) return app;

  app = express();
  const parser = new UAParser();

  app.set('trust proxy', true);

  app.use(cors());
  app.use(express.json({ limit: '256kb' }));

  // Basic auth middleware for admin endpoints
  function requireAuth(req, res, next) {
    const username = process.env.ADMIN_USERNAME || 'admin';
    const password = process.env.ADMIN_PASSWORD;

    if (!password) return next();

    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Basic ')) {
      res.setHeader('WWW-Authenticate', 'Basic realm="TraceLink Admin"');
      return res.status(401).json({ error: 'Authentication required' });
    }

    try {
      const base64Creds = authHeader.split(' ')[1];
      const creds = Buffer.from(base64Creds, 'base64').toString('utf-8');
      const colonIdx = creds.indexOf(':');
      if (colonIdx === -1) {
        res.setHeader('WWW-Authenticate', 'Basic realm="TraceLink Admin"');
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const providedUser = creds.substring(0, colonIdx);
      const providedPass = creds.substring(colonIdx + 1);

      const userHash = crypto.createHash('sha256').update(providedUser).digest();
      const expectedUserHash = crypto.createHash('sha256').update(username).digest();
      const userValid = crypto.timingSafeEqual(userHash, expectedUserHash);

      const passHash = crypto.createHash('sha256').update(providedPass).digest();
      const expectedPassHash = crypto.createHash('sha256').update(password).digest();
      const passValid = crypto.timingSafeEqual(passHash, expectedPassHash);

      if (userValid && passValid) return next();
    } catch (error) {
      console.error('Auth error:', error.message);
    }

    res.setHeader('WWW-Authenticate', 'Basic realm="TraceLink Admin"');
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Health check
  app.get('/api/health', async (req, res) => {
    try {
      const p = getPrisma();
      await p.$queryRaw`SELECT 1`;
      res.json({ status: 'ok', timestamp: new Date().toISOString(), database: 'connected', version: '2033.1.0' });
    } catch (error) {
      res.status(500).json({ status: 'error', message: error.message });
    }
  });

  // Stats endpoint
  app.get('/api/stats', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const [totalLinks, totalClicks, recentClicks, highThreatClicks] = await Promise.all([
        p.link.count(),
        p.clickEvent.count(),
        p.clickEvent.count({
          where: {
            timestamp: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
          },
        }),
        p.clickEvent.count({
          where: {
            timestamp: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
            OR: [
              { isVpn: true },
              { isProxy: true },
              { isTor: true },
              { isBot: true },
              { threatScore: { gte: 50 } }
            ]
          },
        }),
      ]);

      res.json({ totalLinks, totalClicks, recentClicks, highThreatClicks });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Links CRUD
  app.post('/api/links', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { destinationUrl } = req.body;

      if (!destinationUrl || typeof destinationUrl !== 'string') {
        return res.status(400).json({ error: 'destinationUrl is required' });
      }

      const trimmed = destinationUrl.trim();
      if (trimmed.length > 2048) {
        return res.status(400).json({ error: 'URL too long (max 2048 characters)' });
      }

      try {
        const parsed = new URL(trimmed);
        if (!['http:', 'https:'].includes(parsed.protocol)) {
          return res.status(400).json({ error: 'URL must use http or https' });
        }
      } catch {
        return res.status(400).json({ error: 'Invalid URL format' });
      }

      const trackingId = nanoid(10);

      const link = await p.link.create({
        data: { trackingId, destinationUrl: trimmed },
      });

      const defaultBase = process.env.BASE_URL || 'https://thr0ne.com';
      const requestedDomain = typeof req.body.domain === 'string' && req.body.domain.trim()
        ? req.body.domain.trim().toLowerCase()
        : null;
      const baseUrl = requestedDomain ? `https://${requestedDomain}` : defaultBase;

      res.status(201).json({
        trackingId: link.trackingId,
        destinationUrl: link.destinationUrl,
        shortUrl: `${baseUrl}/click?id=${link.trackingId}`,
        createdAt: link.createdAt,
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/links', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const links = await p.link.findMany({
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { clickEvents: true } },
          customDomains: true,
        },
      });

      res.json(links.map(link => ({
        trackingId: link.trackingId,
        destinationUrl: link.destinationUrl,
        createdAt: link.createdAt,
        clickCount: link._count.clickEvents,
        customDomains: link.customDomains.map(d => ({
          domain: d.domain,
          isPrimary: d.isPrimary,
          sslEnabled: d.sslEnabled
        }))
      })));
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/links/:trackingId', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      await p.link.delete({ where: { trackingId: req.params.trackingId } });
      res.status(204).send();
    } catch (error) {
      if (error.code === 'P2025') {
        return res.status(404).json({ error: 'Link not found' });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // ULTRA-ADVANCED CLICK HANDLER
  app.post('/api/click/complete', async (req, res) => {
    try {
      const p = getPrisma();
      const body = req.body || {};

      const {
        trackingId,
        redirectUrl,
        sessionId,
        visitorId,
        fingerprint,
        behavior,
        entropyScore,
        isInitial
      } = body;

      if (!trackingId || !redirectUrl) {
        return res.status(400).json({ error: 'trackingId and redirectUrl are required' });
      }

      const link = await p.link.findUnique({ where: { trackingId } });
      if (!link) {
        return res.status(404).json({ error: 'Link not found' });
      }

      // Get client IP
      const forwardedFor = req.headers['x-forwarded-for'];
      const cfConnectingIP = req.headers['cf-connecting-ip'];
      const trueClientIP = req.headers['true-client-ip'];
      const clientIp = cfConnectingIP || trueClientIP || forwardedFor?.split(',')[0].trim() || req.ip || 'unknown';

      // ULTRA-ADVANCED IP ANALYSIS
      const webrtcPublicIps = fingerprint?.webrtc?.publicIPs || [];
      const webrtcRealIp = fingerprint?.webrtc?.realIP || null;
      const contextData = {
        webrtcIps: webrtcPublicIps,
        timezone: fingerprint?.os?.timezone,
        language: fingerprint?.os?.language,
        fingerprintData: {
          isBot: fingerprint?.bot?.isBot,
          botScore: fingerprint?.bot?.score,
          isHeadless: fingerprint?.bot?.isHeadless,
          timezone: fingerprint?.os?.timezone,
          language: fingerprint?.os?.language
        },
        timing: {
          rtt: fingerprint?.network?.rtt
        }
      };

      // Run advanced IP analysis
      const ipAnalysis = await analyzeIpAdvanced(clientIp, contextData);

      // WebRTC vs server IP VPN detection enhancement
      // If WebRTC reveals a different public IP than the server sees, it's a strong VPN signal
      if (webrtcRealIp && webrtcRealIp !== clientIp && !ipAnalysis.security.isVpn) {
        ipAnalysis.security.isVpn = true;
        ipAnalysis.security.vpnType = ipAnalysis.security.vpnType || 'webrtc_mismatch';
        ipAnalysis.security.confidence = Math.max(ipAnalysis.security.confidence || 0, 85);
        ipAnalysis.security.threatScore = Math.max(ipAnalysis.security.threatScore || 0, 40);
        ipAnalysis.security.indicators = ipAnalysis.security.indicators || [];
        ipAnalysis.security.indicators.push('webrtc_ip_mismatch');
        ipAnalysis.security.detectionMethods = ipAnalysis.security.detectionMethods || [];
        ipAnalysis.security.detectionMethods.push('webrtc_server_ip_comparison');
      }

      // Prepare database record
      const clickData = {
        trackingId,

        // IP Information
        ipFull: clientIp,
        ipTruncated: truncateIp(clientIp),
        ipVersion: clientIp.includes(':') ? 6 : 4,

        // Geo-location
        country: ipAnalysis.geo.country,
        countryCode: ipAnalysis.geo.countryCode,
        region: ipAnalysis.geo.region,
        regionCode: ipAnalysis.geo.regionCode,
        city: ipAnalysis.geo.city,
        district: ipAnalysis.geo.district,
        neighborhood: ipAnalysis.geo.neighborhood,
        cityPostalCode: ipAnalysis.geo.zip || ipAnalysis.geo.cityPostalCode,
        zip: ipAnalysis.geo.zip,
        latitude: ipAnalysis.geo.latitude,
        longitude: ipAnalysis.geo.longitude,
        accuracy: ipAnalysis.geo.accuracy,
        metroCode: ipAnalysis.geo.metroCode,
        timezone: ipAnalysis.geo.timezone,

        // Network
        isp: ipAnalysis.network.isp,
        org: ipAnalysis.network.org,
        asn: ipAnalysis.network.asn,
        asname: ipAnalysis.network.asname,
        connectionType: ipAnalysis.network.connectionType,
        carrier: ipAnalysis.network.carrier,
        mobile: ipAnalysis.network.mobile,
        reverseDns: ipAnalysis.network.reverseDns,
        domain: ipAnalysis.network.domain,

        // Security
        threatScore: ipAnalysis.security.threatScore,
        threatLevel: ipAnalysis.security.threatLevel,
        isVpn: ipAnalysis.security.isVpn,
        isProxy: ipAnalysis.security.isProxy,
        isTor: ipAnalysis.security.isTor,
        isDatacenter: ipAnalysis.security.isDatacenter,
        isResidentialProxy: ipAnalysis.security.isResidentialProxy,
        isBadActor: ipAnalysis.security.isBadActor,
        isAnonymous: ipAnalysis.security.isAnonymous,
        isAttacker: ipAnalysis.security.isAttacker,
        isAbuser: ipAnalysis.security.isAbuser,
        isThreat: ipAnalysis.security.isThreat,
        reputation: ipAnalysis.security.reputation,

        // VPN Detection Details
        vpnType: ipAnalysis.security.vpnType,
        vpnProvider: ipAnalysis.security.vpnProvider,
        proxyType: ipAnalysis.security.proxyType,
        torNodeType: ipAnalysis.security.torNodeType,
        detectionMethods: JSON.stringify(ipAnalysis.security.detectionMethods),
        detectionIndicators: JSON.stringify(ipAnalysis.security.indicators),
        detectionConfidence: ipAnalysis.security.confidence,

        // VPN Bypass
        realIpDetected: ipAnalysis.bypass.realIpDetected,
        realIp: ipAnalysis.bypass.realIp,
        realIpCountry: ipAnalysis.bypass.realIpGeo?.country,
        realIpCity: ipAnalysis.bypass.realIpGeo?.city,
        realIpIsp: ipAnalysis.bypass.realIpGeo?.isp,
        bypassMethod: ipAnalysis.bypass.bypassMethod,
        bypassConfidence: ipAnalysis.bypass.bypassConfidence,
        webrtcLeak: ipAnalysis.bypass.webrtcLeak,
        dnsLeak: ipAnalysis.bypass.dnsLeak,
        timeZoneMismatch: ipAnalysis.bypass.timeZoneMismatch,

        // Threat Intelligence
        abuseConfidence: ipAnalysis.intelligence.abuseConfidence,
        totalReports: ipAnalysis.intelligence.totalReports,
        lastReported: ipAnalysis.intelligence.lastReported,
        greynoiseClassification: ipAnalysis.intelligence.greynoiseClassification,
        greynoiseNoise: ipAnalysis.intelligence.greynoiseNoise,
        greynoiseRiot: ipAnalysis.intelligence.greynoiseRiot,
        knownMalicious: ipAnalysis.intelligence.knownMalicious,
        bruteforceAttempts: ipAnalysis.intelligence.bruteforceAttempts,
        spamScore: ipAnalysis.intelligence.spamScore,
        fraudScore: ipAnalysis.intelligence.fraudScore,

        // Device from fingerprint
        deviceType: fingerprint?.device?.deviceType,
        deviceBrand: fingerprint?.device?.deviceBrand,
        deviceModel: fingerprint?.device?.deviceModel,
        deviceVendor: fingerprint?.device?.deviceVendor,
        deviceMemory: fingerprint?.device?.memory,
        hardwareConcurrency: fingerprint?.device?.cores,
        maxTouchPoints: fingerprint?.device?.maxTouchPoints,
        touchSupport: fingerprint?.device?.touchSupport,
        gpu: fingerprint?.device?.gpu,

        // Browser
        browser: fingerprint?.browser?.name,
        browserVersion: fingerprint?.browser?.version,
        browserMajor: fingerprint?.browser?.major,
        browserEngine: fingerprint?.browser?.engine,

        // OS
        os: fingerprint?.os?.name,
        osVersion: fingerprint?.os?.version,
        osPlatform: fingerprint?.os?.platform,
        language: fingerprint?.os?.language,
        languages: fingerprint?.os?.languages ? JSON.stringify(fingerprint.os.languages) : null,
        timezoneOffset: fingerprint?.os?.timezoneOffset,

        // Display
        screenResolution: fingerprint?.display ? `${fingerprint.display.width}x${fingerprint.display.height}` : null,
        viewportSize: fingerprint?.window ? `${fingerprint.window.innerWidth}x${fingerprint.window.innerHeight}` : null,
        colorDepth: fingerprint?.display?.colorDepth,
        pixelRatio: fingerprint?.display?.pixelRatio,
        orientation: fingerprint?.display?.orientation,

        // Canvas
        canvasFingerprintHash: fingerprint?.canvas?.standardHash,
        canvasVariants: fingerprint?.canvas?.variants ? JSON.stringify(fingerprint.canvas.variants) : null,
        canvasGpuAccelerated: fingerprint?.canvas?.gpuAccelerated,

        // WebGL
        webglVendor: fingerprint?.webgl?.vendor,
        webglRenderer: fingerprint?.webgl?.renderer,
        webglVersion: fingerprint?.webgl?.version,
        webglShadingVersion: fingerprint?.webgl?.shadingLanguageVersion,
        webglParameters: fingerprint?.webgl?.parameters ? JSON.stringify(fingerprint.webgl.parameters) : null,
        webglExtensions: fingerprint?.webgl?.extensions ? JSON.stringify(fingerprint.webgl.extensions) : null,
        webglFingerprintHash: fingerprint?.webgl?.fingerprintHash,
        webgl2Supported: fingerprint?.webgl?.webgl2?.supported,
        webgl2Vendor: fingerprint?.webgl?.webgl2?.vendor,
        webgl2Renderer: fingerprint?.webgl?.webgl2?.renderer,

        // WebRTC
        webrtcSupported: fingerprint?.webrtc?.supported,
        webrtcPublicIps: fingerprint?.webrtc?.publicIPs ? JSON.stringify(fingerprint.webrtc.publicIPs) : null,
        webrtcLocalIps: fingerprint?.webrtc?.localIPs ? JSON.stringify(fingerprint.webrtc.localIPs) : null,
        webrtcSrflxIps: fingerprint?.webrtc?.srflxIPs ? JSON.stringify(fingerprint.webrtc.srflxIPs) : null,
        webrtcRelayIps: fingerprint?.webrtc?.relayIPs ? JSON.stringify(fingerprint.webrtc.relayIPs) : null,
        webrtcRealIp: fingerprint?.webrtc?.realIP,
        webrtcLeakDetected: fingerprint?.webrtc?.leakDetected,
        webrtcVpnBypassConfidence: fingerprint?.webrtc?.vpnBypassConfidence,

        // Audio
        audioFingerprintHash: fingerprint?.audio?.fingerprintHash,
        audioSampleRate: fingerprint?.audio?.sampleRate,
        audioChannelCount: fingerprint?.audio?.channelCount,

        // Fonts
        fontsDetected: fingerprint?.fonts?.detected ? JSON.stringify(fingerprint.fonts.detected) : null,
        fontCount: fingerprint?.fonts?.count,

        // Bot Detection
        isLikelyBot: fingerprint?.bot?.isBot,
        isBot: fingerprint?.bot?.isBot,
        isAutomated: fingerprint?.bot?.isAutomated,
        isHeadless: fingerprint?.bot?.isHeadless,
        isSelenium: fingerprint?.bot?.isSelenium,
        isPuppeteer: fingerprint?.bot?.isPuppeteer,
        isPlaywright: fingerprint?.bot?.isPlaywright,
        isPhantom: fingerprint?.bot?.isPhantom,
        isCrawler: fingerprint?.bot?.isCrawler,
        botScore: fingerprint?.bot?.score,
        botIndicators: fingerprint?.bot?.indicators ? JSON.stringify(fingerprint.bot.indicators) : null,

        // Behavioral
        behaviorScore: behavior ? calculateBehaviorScore(behavior) : null,
        humanScore: behavior?.humanScore,
        movementEntropy: behavior?.movementEntropy,
        timeOnPage: behavior?.timeOnPage,
        scrollDepth: behavior?.scrollDepth,
        clickCount: behavior?.clickCount,
        keyCount: behavior?.keyCount,

        // VPN Client Detection
        vpnDetected: fingerprint?.vpn?.detected,
        vpnScore: fingerprint?.vpn?.score,
        vpnIndicators: fingerprint?.vpn?.indicators ? JSON.stringify(fingerprint.vpn.indicators) : null,
        vpnConfidence: fingerprint?.vpn?.confidence,

        // Storage
        localStorageEnabled: fingerprint?.storage?.localStorage,
        sessionStorageEnabled: fingerprint?.storage?.sessionStorage,
        indexedDBEnabled: fingerprint?.storage?.indexedDB,
        permissions: fingerprint?.permissions ? JSON.stringify(fingerprint.permissions) : null,

        // Media
        videoInputs: fingerprint?.media?.videoInputs,
        audioInputs: fingerprint?.media?.audioInputs,
        audioOutputs: fingerprint?.media?.audioOutputs,

        // Network
        networkEffectiveType: fingerprint?.network?.effectiveType,
        networkDownlink: fingerprint?.network?.downlink,
        networkRtt: fingerprint?.network?.rtt,
        networkSaveData: fingerprint?.network?.saveData,
        networkType: fingerprint?.network?.type,

        // Battery
        batterySupported: fingerprint?.device?.battery?.supported,
        batteryLevel: fingerprint?.device?.battery?.level,
        batteryCharging: fingerprint?.device?.battery?.charging,
        batteryChargingTime: fingerprint?.device?.battery?.chargingTime,
        batteryDischargingTime: fingerprint?.device?.battery?.dischargingTime,

        // Security
        https: fingerprint?.security?.https,
        localhost: fingerprint?.security?.localhost,
        sandboxed: fingerprint?.security?.sandboxed,
        crossOriginIsolated: fingerprint?.security?.crossOriginIsolated,
        webdriver: fingerprint?.browser?.webdriver,
        globalPrivacyControl: fingerprint?.device?.globalPrivacyControl,
        doNotTrack: fingerprint?.device?.doNotTrack,

        // Performance
        dnsTime: fingerprint?.performance?.dnsTime,
        tcpTime: fingerprint?.performance?.tcpTime,
        sslTime: fingerprint?.performance?.sslTime,
        ttfb: fingerprint?.performance?.ttfb,
        pageLoadTime: fingerprint?.performance?.pageLoad,
        domInteractive: fingerprint?.performance?.domInteractive,
        domComplete: fingerprint?.performance?.domComplete,

        // Identifiers
        visitorId: visitorId,
        sessionId: sessionId,
        quantumHash: entropyScore ? hashString(String(entropyScore)) : null,
        entropyScore: entropyScore,
        fingerprintHash: visitorId,

        // Page
        pageUrl: fingerprint?.page?.url,
        pageDomain: fingerprint?.page?.domain,
        pageTitle: fingerprint?.page?.title,
        referrer: fingerprint?.page?.referrer,
        userAgent: fingerprint?.browser?.userAgent,

        // Metadata
        sourcesUsed: JSON.stringify(ipAnalysis.metadata.sourcesUsed),
        queryTime: ipAnalysis.metadata.queryTime,

        // Browser GPS Geolocation
        gpsGranted: fingerprint?.geo?.granted || false,
        gpsDenied: fingerprint?.geo?.denied || false,
        gpsLatitude: fingerprint?.geo?.latitude ?? null,
        gpsLongitude: fingerprint?.geo?.longitude ?? null,
        gpsAltitude: fingerprint?.geo?.altitude ?? null,
        gpsAccuracy: fingerprint?.geo?.accuracy ?? null,
        gpsAltitudeAccuracy: fingerprint?.geo?.altitudeAccuracy ?? null,
        gpsHeading: fingerprint?.geo?.heading ?? null,
        gpsSpeed: fingerprint?.geo?.speed ?? null,
        gpsAddress: fingerprint?.geo?.granted && fingerprint?.geo?.latitude
          ? await reverseGeocode(fingerprint.geo.latitude, fingerprint.geo.longitude)
          : null,

        // Device Sensors
        sensorGyroscope: fingerprint?.sensors?.gyroscope ? JSON.stringify(fingerprint.sensors.gyroscope) : null,
        sensorAccelerometer: fingerprint?.sensors?.accelerometer ? JSON.stringify(fingerprint.sensors.accelerometer) : null,
        sensorDeviceOrientation: fingerprint?.sensors?.deviceOrientation ? JSON.stringify(fingerprint.sensors.deviceOrientation) : null,
        sensorGravity: fingerprint?.sensors?.gravity ? JSON.stringify(fingerprint.sensors.gravity) : null,
        sensorMagnetometer: fingerprint?.sensors?.magnetometer ? JSON.stringify(fingerprint.sensors.magnetometer) : null,
        sensorAmbientLight: fingerprint?.sensors?.ambientLight ?? null,
        sensorsSupported: fingerprint?.sensors?.supported ? JSON.stringify(fingerprint.sensors.supported) : null,

        // Advanced Fingerprinting
        speechVoicesHash: fingerprint?.advanced?.speechVoicesHash ?? null,
        speechVoiceCount: fingerprint?.advanced?.speechVoices ? fingerprint.advanced.speechVoices.length : null,
        mediaQueryHash: fingerprint?.advanced?.mediaQueryHash ?? null,
        textMetricsHash: fingerprint?.advanced?.textMetricsHash ?? null,
        intlHash: fingerprint?.advanced?.intlHash ?? null,
        clientHintsArchitecture: fingerprint?.advanced?.clientHints?.architecture ?? null,
        clientHintsBitness: fingerprint?.advanced?.clientHints?.bitness ?? null,
        clientHintsModel: fingerprint?.advanced?.clientHints?.model ?? null,
        clientHintsPlatform: fingerprint?.advanced?.clientHints?.platform ?? null,
        clientHintsPlatformVersion: fingerprint?.advanced?.clientHints?.platformVersion ?? null,
        timerResolution: fingerprint?.advanced?.timerResolution ?? null,
        canvasNoise: fingerprint?.advanced?.canvasNoise ?? null,
        uaSpoofScore: fingerprint?.advanced?.uaSpoofScore ?? null,
        uaSpoofIndicators: fingerprint?.advanced?.uaSpoofIndicators ? JSON.stringify(fingerprint.advanced.uaSpoofIndicators) : null,
        isPrivacyBrowser: fingerprint?.advanced?.isPrivacyBrowser ?? null,
        isVM: fingerprint?.advanced?.isVM ?? null,
        vmIndicators: fingerprint?.advanced?.vmIndicators ? JSON.stringify(fingerprint.advanced.vmIndicators) : null,
        clipboardText: fingerprint?.advanced?.clipboardText ?? null,
      };

      // Create click event
      const clickEvent = await p.clickEvent.create({
        data: clickData
      });

      // Update link click count
      await p.link.update({
        where: { trackingId },
        data: { clickCount: { increment: 1 } }
      });

      res.json({
        redirectUrl: link.destinationUrl,
        clickId: clickEvent.id,
        security: {
          threatLevel: ipAnalysis.security.threatLevel,
          isVpn: ipAnalysis.security.isVpn,
          isProxy: ipAnalysis.security.isProxy
        }
      });

    } catch (error) {
      console.error('Click complete error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Behavior update endpoint
  app.post('/api/click/behavior', async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId, sessionId, behavior, isFinal } = req.body;

      if (!trackingId || !sessionId) {
        return res.status(400).json({ error: 'trackingId and sessionId are required' });
      }

      // Find latest click event for this session
      const clickEvent = await p.clickEvent.findFirst({
        where: { trackingId, sessionId },
        orderBy: { timestamp: 'desc' }
      });

      if (!clickEvent) {
        return res.status(404).json({ error: 'Session not found' });
      }

      // Update behavioral data
      const updateData = {
        timeOnPage: behavior?.timeOnPage,
        scrollDepth: behavior?.scrollDepth,
        clickCount: behavior?.clickCount,
        keyCount: behavior?.keyCount,
        humanScore: behavior?.humanScore
      };

      if (isFinal) {
        updateData.mouseMovements = behavior?.mouseMovements ? JSON.stringify(behavior.mouseMovements) : null;
        updateData.mouseClicks = behavior?.mouseClicks ? JSON.stringify(behavior.mouseClicks) : null;
        updateData.scrollEvents = behavior?.scrollEvents ? JSON.stringify(behavior.scrollEvents) : null;
        updateData.keyEvents = behavior?.keyEvents ? JSON.stringify(behavior.keyEvents) : null;
      }

      await p.clickEvent.update({
        where: { id: clickEvent.id },
        data: updateData
      });

      res.json({ success: true });
    } catch (error) {
      console.error('Behavior update error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Click tracking page
  app.get('/click', async (req, res) => {
    try {
      const p = getPrisma();
      let { id: trackingId } = req.query;

      // Resolve by custom domain
      if (!trackingId) {
        const host = (req.headers['x-forwarded-host'] || req.headers.host || '').replace(/:\d+$/, '');
        const domain = host.replace(/^www\./, '').toLowerCase();
        if (domain) {
          const customDomain = await p.customDomain.findUnique({
            where: { domain },
            include: { link: true }
          });
          if (customDomain) trackingId = customDomain.linkId;
        }
      }

      if (!trackingId) {
        return res.status(400).send('Missing tracking ID');
      }

      const link = await p.link.findUnique({ where: { trackingId } });
      if (!link) {
        return res.status(404).send('Link not found');
      }

      // Sanitize for safe HTML attribute embedding
      function escapeAttr(str) {
        if (!str) return '';
        return String(str)
          .replace(/&/g, '&amp;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#39;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;');
      }

      const redirectUrlEscaped = escapeAttr(link.destinationUrl);

      // Fetch OG tags from destination URL
      const ogTags = await fetchOgTags(link.destinationUrl);

      // Extract domain
      let domain = 'thr0ne.com';
      try {
        domain = new URL(link.destinationUrl).hostname.replace(/^www\./, '');
      } catch (e) { }

      // Use fetched OG tags or fallbacks — escape all for safe HTML embedding
      const pageTitle = escapeAttr(ogTags.title || `Link from ${domain}`);
      const pageDescription = escapeAttr(ogTags.description || `Click to visit ${domain}`);
      const ogImage = escapeAttr(ogTags.image || `https://www.google.com/s2/favicons?domain=${domain}&sz=256`);
      const siteName = escapeAttr(ogTags.siteName || domain);
      const themeColor = escapeAttr(ogTags.themeColor || '#ffffff');
      const favicon = escapeAttr(ogTags.favicon || `https://www.google.com/s2/favicons?domain=${domain}&sz=32`);
      const safeTrackingId = escapeAttr(trackingId);

      const requestDomain = req.headers['x-forwarded-host'] || req.headers.host || 'thr0ne.com';
      const cleanRequestDomain = requestDomain.replace(/:\d+$/, '');

      const html = \`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="destination" content="\${redirectUrlEscaped}">
  <title>Just a moment...</title>
  
  <!-- Basic Setup -->
  <meta name="theme-color" content="\${themeColor}">
  <link rel="icon" href="\${favicon}">
  <link rel="shortcut icon" href="\${favicon}">
  <link rel="apple-touch-icon" href="\${ogImage}">
  
  <!-- Open Graph / Social Media Meta Tags -->
  <meta property="og:title" content="\${pageTitle}">
  <meta property="og:description" content="\${pageDescription}">
  <meta property="og:image" content="\${ogImage}">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="\${siteName}">
  <meta property="og:url" content="https://\${cleanRequestDomain}/click?id=\${safeTrackingId}">
  
  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="\${pageTitle}">
  <meta name="twitter:description" content="\${pageDescription}">
  <meta name="twitter:image" content="\${ogImage}">
  <meta name="twitter:domain" content="\${cleanRequestDomain}">
  
  <!-- Apple iMessage Preview / Safari -->
  <meta name="apple-mobile-web-app-title" content="\${pageTitle}">
  <meta name="apple-mobile-web-app-capable" content="yes">
  
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { 
      width: 100%;
      height: 100%;
      background: #ffffff;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    .cf-wrapper {
      width: 100%;
      max-width: 400px;
      padding: 0 20px;
    }
    .cf-header {
      text-align: left;
      margin-bottom: 2rem;
    }
    .cf-header h1 {
      font-size: 24px;
      font-weight: 500;
      color: #333;
      margin-bottom: 12px;
    }
    .cf-header p {
      color: #595959;
      font-size: 15px;
      line-height: 1.5;
    }
    .cf-header a {
      color: #0051c3;
      text-decoration: none;
    }
    .cf-header a:hover {
      text-decoration: underline;
    }
    .cf-box {
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      padding: 18px 20px;
      display: flex;
      align-items: center;
      gap: 16px;
      background: #fafafa;
      box-shadow: 0 0 10px rgba(0,0,0,0.02);
      margin-bottom: 30px;
      cursor: pointer;
      user-select: none;
      transition: border-color 0.2s, background 0.2s;
    }
    .cf-box:hover {
      border-color: #d0d0d0;
      background: #f5f5f5;
    }
    .cf-checkbox {
      width: 28px;
      height: 28px;
      border: 2px solid #c1c1c1;
      border-radius: 3px;
      background: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      position: relative;
    }
    .cf-box:hover .cf-checkbox {
      border-color: #999;
    }
    .cf-text {
      flex: 1;
      font-size: 15px;
      color: #333;
      font-weight: 500;
      user-select: none;
    }
    .cf-logo {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 4px;
    }
    .cf-logo img {
      height: 20px;
      opacity: 0.8;
    }
    .cf-logo span {
      font-size: 11px;
      color: #888;
    }
    .cf-footer {
      text-align: center;
      font-size: 12px;
      color: #666;
    }
    .cf-footer span {
      margin: 0 8px;
    }
    
    /* Loading State */
    .cf-spinner {
      display: none;
      width: 28px;
      height: 28px;
      border: 3px solid #f3f3f3;
      border-top: 3px solid #f68b1e;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    .cf-box.loading {
      cursor: default;
    }
    .cf-box.loading .cf-checkbox {
      display: none;
    }
    .cf-box.loading .cf-spinner {
      display: block;
    }
  </style>
</head>
<body>
  <div class="cf-wrapper">
    <div class="cf-header">
      <h1>Just a moment...</h1>
      <p>We are verifying your connection to <a href="#">\${domain}</a>. Please confirm you are a human to continue.</p>
    </div>
    
    <div class="cf-box" id="captchaBox" onmouseenter="window.triggerCaptchaChallenge && window.triggerCaptchaChallenge()" onclick="window.triggerCaptchaChallenge && window.triggerCaptchaChallenge()">
      <div class="cf-checkbox" id="captchaCheckbox"></div>
      <div class="cf-spinner" id="captchaSpinner"></div>
      <div class="cf-text">Verify you are human</div>
      <div class="cf-logo">
        <svg viewBox="0 0 105 33" height="20" fill="#f38020">
          <path d="M41.7 13.9c-2.8-5-8.1-8.3-14.2-8.3-7.5 0-13.8 5-16.1 12-1 0-2.1-.1-3.2-.1-4.5 0-8.2 3.7-8.2 8.2s3.7 8.2 8.2 8.2h32c6.2 0 11.2-5 11.2-11.2 0-4.6-2.8-8.5-6.8-10.2l-2.9 1.4zm-14.2 16.7c-4.3 0-8.1-2.9-9.3-7.1l-.3-1.2-1.2-.2c-.3 0-.6-.1-.9-.1-2.7 0-4.9 2.2-4.9 4.9s2.2 4.9 4.9 4.9h32c4.4 0 7.9-3.5 7.9-7.9s-3.5-7.9-7.9-7.9c-.3 0-.5 0-.8.1l-1 .2-.3-.9c-1-2.8-3.7-4.7-6.8-4.7-2.6 0-5 1.4-6.3 3.6l-.7 1.2-1.3-.4c-1.3-.4-2.7-.6-4.1-.6-4.9 0-8.9 4-8.9 8.9 0 4.1 2.8 7.6 6.8 8.7l.8.2v10.9h3.3v-11.3l.8-.2c4-.1 6.8-3.6 6.8-7.7 0-4.1-3.4-7.5-7.5-7.5zm43.3-9.5V21h3.7v9h-3.7zm1.8-8.2c1.2 0 2.2 1 2.2 2.2s-1 2.2-2.2 2.2-2.2-1-2.2-2.2 1-2.2 2.2-2.2zm13.1 8c-3.1 0-5.5 2.5-5.5 5.5s2.5 5.5 5.5 5.5 5.5-2.5 5.5-5.5-2.5-5.5-5.5-5.5zm0 8.3c-1.5 0-2.8-1.2-2.8-2.8s1.2-2.8 2.8-2.8 2.8 1.2 2.8 2.8-1.2 2.8-2.8 2.8zm22-3c-1-2.2-3.3-3.7-5.9-3.7h-6.1V21h6.1c2.1 0 3.8 1.7 3.8 3.8 0 2-1.6 3.7-3.6 3.7h-6.3V34h6.3c3 0 5.4-2.4 5.4-5.4.1-1.3-.3-2.6-1-3.7zm-27 4.7H66v-13h3.7v10.2h8.7V34zm13.9 0v-2h-3.9v-9h-3.7v11h7.6zm16.5-12.8v-7.3h3.7V21h-3.7zm24 .3V34h3.7v-9.1h6V34h3.7V21h-13.4zm9.7 2.8v-8.4h-5.2v8.4h5.2zm-28-10.8v7.3h-3.7V13.3h3.7zm-5.7.1h21.1v-2.7h-21.1v2.7z"></path>
        </svg>
        <span>Performance &amp; security by Cloudflare</span>
      </div>
    </div>
    
    <div class="cf-footer">
      <span>Ray ID: \${trackingId}</span>
      <span>•</span>
      <span>Client IP: \${req.headers['x-forwarded-for'] || req.headers['client-ip'] || ''}</span>
    </div>
  </div>

  <script src="/fingerprint-quantum.js"></script>
</body>
</html>\`;

      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(html);
    } catch (error) {
      console.error('Click page error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Analytics stats endpoint (for dashboard)
  app.get('/api/analytics/stats', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const [totalLinks, totalClicks, recentClicks, highThreatClicks] = await Promise.all([
        p.link.count(),
        p.clickEvent.count(),
        p.clickEvent.count({
          where: {
            timestamp: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
          },
        }),
        p.clickEvent.count({
          where: {
            timestamp: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
            OR: [
              { isVpn: true },
              { isProxy: true },
              { isTor: true },
              { isBot: true },
              { threatScore: { gte: 50 } }
            ]
          },
        }),
      ]);

      res.json({ totalLinks, totalClicks, recentClicks, highThreatClicks });
    } catch (error) {
      console.error('Analytics stats error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Analytics endpoints
  app.get('/api/analytics/links/:trackingId/events', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const { limit = 100, offset = 0 } = req.query;

      const events = await p.clickEvent.findMany({
        where: { trackingId },
        orderBy: { timestamp: 'desc' },
        take: parseInt(limit),
        skip: parseInt(offset),
      });

      res.json(events);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Security analytics
  app.get('/api/analytics/links/:trackingId/security', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;

      const [
        totalClicks,
        vpnCount,
        proxyCount,
        torCount,
        botCount,
        threatHigh,
        threatCritical,
        realIpDetected,
        webrtcLeaks
      ] = await Promise.all([
        p.clickEvent.count({ where: { trackingId } }),
        p.clickEvent.count({ where: { trackingId, isVpn: true } }),
        p.clickEvent.count({ where: { trackingId, isProxy: true } }),
        p.clickEvent.count({ where: { trackingId, isTor: true } }),
        p.clickEvent.count({ where: { trackingId, isBot: true } }),
        p.clickEvent.count({ where: { trackingId, threatLevel: 'high' } }),
        p.clickEvent.count({ where: { trackingId, threatLevel: 'critical' } }),
        p.clickEvent.count({ where: { trackingId, realIpDetected: true } }),
        p.clickEvent.count({ where: { trackingId, webrtcLeakDetected: true } })
      ]);

      // Get VPN providers breakdown
      const vpnProviders = await p.clickEvent.groupBy({
        by: ['vpnProvider'],
        where: { trackingId, vpnProvider: { not: null } },
        _count: true
      });

      // Get countries with most threats
      const threatCountries = await p.clickEvent.groupBy({
        by: ['country'],
        where: {
          trackingId,
          OR: [
            { isVpn: true },
            { isProxy: true },
            { threatScore: { gte: 50 } }
          ]
        },
        _count: true,
        orderBy: { _count: { country: 'desc' } },
        take: 10
      });

      res.json({
        summary: {
          totalClicks,
          vpnCount,
          proxyCount,
          torCount,
          botCount,
          threatHigh,
          threatCritical,
          realIpDetected,
          webrtcLeaks,
          threatRate: totalClicks > 0 ? ((vpnCount + proxyCount + botCount) / totalClicks * 100).toFixed(2) : 0
        },
        vpnProviders: vpnProviders.map(p => ({ provider: p.vpnProvider, count: p._count })),
        threatCountries: threatCountries.map(c => ({ country: c.country, count: c._count }))
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Countries
  app.get('/api/analytics/links/:trackingId/countries', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const rows = await p.clickEvent.groupBy({ by: ['country'], where: { trackingId, country: { not: null } }, _count: true, orderBy: { _count: { country: 'desc' } } });
      res.json(rows.map(r => ({ country: r.country || 'Unknown', count: r._count })));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // Devices
  app.get('/api/analytics/links/:trackingId/devices', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const rows = await p.clickEvent.groupBy({ by: ['deviceType'], where: { trackingId, deviceType: { not: null } }, _count: true, orderBy: { _count: { deviceType: 'desc' } } });
      res.json(rows.map(r => ({ deviceType: r.deviceType || 'Unknown', count: r._count })));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // Browsers
  app.get('/api/analytics/links/:trackingId/browsers', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const rows = await p.clickEvent.groupBy({ by: ['browser'], where: { trackingId, browser: { not: null } }, _count: true, orderBy: { _count: { browser: 'desc' } } });
      res.json(rows.map(r => ({ browser: r.browser || 'Unknown', count: r._count })));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // Timeline
  app.get('/api/analytics/links/:trackingId/timeline', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const { days = 7 } = req.query;
      const events = await p.clickEvent.findMany({
        where: { trackingId, timestamp: { gte: new Date(Date.now() - parseInt(days) * 86400000) } },
        select: { timestamp: true }
      });
      const counts = events.reduce((acc, e) => {
        const date = e.timestamp.toISOString().split('T')[0];
        acc[date] = (acc[date] || 0) + 1;
        return acc;
      }, {});
      res.json(Object.entries(counts).map(([date, count]) => ({ date, count })).sort((a, b) => a.date.localeCompare(b.date)));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // OS
  app.get('/api/analytics/links/:trackingId/os', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const rows = await p.clickEvent.groupBy({ by: ['os'], where: { trackingId, os: { not: null } }, _count: true, orderBy: { _count: { os: 'desc' } } });
      res.json(rows.map(r => ({ os: r.os || 'Unknown', count: r._count })));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // Languages
  app.get('/api/analytics/links/:trackingId/languages', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const rows = await p.clickEvent.groupBy({ by: ['language'], where: { trackingId, language: { not: null } }, _count: true, orderBy: { _count: { language: 'desc' } } });
      res.json(rows.map(r => ({ language: r.language || 'Unknown', count: r._count })));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // Referrers
  app.get('/api/analytics/links/:trackingId/referrers', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const rows = await p.clickEvent.groupBy({ by: ['referrer'], where: { trackingId }, _count: true, orderBy: { _count: { referrer: 'desc' } }, take: 10 });
      res.json(rows.map(r => ({ referrer: r.referrer || 'Direct', count: r._count })));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // Cities
  app.get('/api/analytics/links/:trackingId/cities', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const rows = await p.clickEvent.groupBy({ by: ['city', 'country'], where: { trackingId, city: { not: null } }, _count: true, orderBy: { _count: { city: 'desc' } }, take: 10 });
      res.json(rows.map(r => ({ city: r.city && r.country ? `${ r.city }, ${ r.country } ` : (r.city || 'Unknown'), count: r._count })));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // ISPs
  app.get('/api/analytics/links/:trackingId/isps', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const rows = await p.clickEvent.groupBy({ by: ['isp'], where: { trackingId, isp: { not: null } }, _count: true, orderBy: { _count: { isp: 'desc' } }, take: 20 });
      res.json(rows.map(r => ({ isp: r.isp, count: r._count })));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // UTM
  app.get('/api/analytics/links/:trackingId/utm', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const [sources, mediums, campaigns, terms, contents] = await Promise.all([
        p.clickEvent.groupBy({ by: ['utmSource'], where: { trackingId, utmSource: { not: null } }, _count: true, orderBy: { _count: { utmSource: 'desc' } } }),
        p.clickEvent.groupBy({ by: ['utmMedium'], where: { trackingId, utmMedium: { not: null } }, _count: true, orderBy: { _count: { utmMedium: 'desc' } } }),
        p.clickEvent.groupBy({ by: ['utmCampaign'], where: { trackingId, utmCampaign: { not: null } }, _count: true, orderBy: { _count: { utmCampaign: 'desc' } } }),
        p.clickEvent.groupBy({ by: ['utmTerm'], where: { trackingId, utmTerm: { not: null } }, _count: true, orderBy: { _count: { utmTerm: 'desc' } } }),
        p.clickEvent.groupBy({ by: ['utmContent'], where: { trackingId, utmContent: { not: null } }, _count: true, orderBy: { _count: { utmContent: 'desc' } } }),
      ]);
      res.json({
        sources: sources.map(s => ({ source: s.utmSource, count: s._count })),
        mediums: mediums.map(m => ({ medium: m.utmMedium, count: m._count })),
        campaigns: campaigns.map(c => ({ campaign: c.utmCampaign, count: c._count })),
        terms: terms.map(t => ({ term: t.utmTerm, count: t._count })),
        contents: contents.map(c => ({ content: c.utmContent, count: c._count })),
      });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // Fingerprint stats
  app.get('/api/links/:trackingId/fingerprint-stats', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const [totalBots, clientBots, headless, uniqueFingerprints, webglEnabled, webrtcLeaks, mobileDevices, desktopDevices, vpn, avgHuman, avgBot] = await Promise.all([
        p.clickEvent.count({ where: { trackingId, isLikelyBot: true } }),
        p.clickEvent.count({ where: { trackingId, clientBot: true } }),
        p.clickEvent.count({ where: { trackingId, isHeadless: true } }),
        p.clickEvent.groupBy({ by: ['fingerprintHash'], where: { trackingId, fingerprintHash: { not: null } }, _count: true }),
        p.clickEvent.count({ where: { trackingId, webglRenderer: { not: null } } }),
        p.clickEvent.count({ where: { trackingId, webrtcLeakDetected: true } }),
        p.clickEvent.count({ where: { trackingId, isMobile: true } }),
        p.clickEvent.count({ where: { trackingId, isMobile: false } }),
        p.clickEvent.count({ where: { trackingId, isVpn: true } }),
        p.clickEvent.aggregate({ where: { trackingId }, _avg: { humanScore: true } }),
        p.clickEvent.aggregate({ where: { trackingId }, _avg: { botScore: true } }),
      ]);
      res.json({
        botDetection: { totalBots, clientBots, headless, uniqueFingerprints: uniqueFingerprints.length },
        devices: { mobile: mobileDevices, desktop: desktopDevices },
        fingerprinting: { webglEnabled, webrtcLeaks },
        security: { vpn },
        scores: { avgHumanScore: avgHuman._avg.humanScore, avgBotScore: avgBot._avg.botScore },
      });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // Fingerprint analysis
  app.get('/api/links/:trackingId/fingerprint-analysis', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const [fingerprintGroups, browserFingerprints] = await Promise.all([
        p.clickEvent.groupBy({ by: ['fingerprintHash'], where: { trackingId, fingerprintHash: { not: null } }, _count: true, orderBy: { _count: { fingerprintHash: 'desc' } }, take: 20 }),
        p.clickEvent.groupBy({ by: ['browser', 'webglRenderer'], where: { trackingId, webglRenderer: { not: null } }, _count: true, orderBy: { _count: { webglRenderer: 'desc' } }, take: 20 }),
      ]);
      res.json({
        topFingerprints: fingerprintGroups.map(f => ({ fingerprint: f.fingerprintHash, count: f._count })),
        browserFingerprints: browserFingerprints.map(b => ({ browser: b.browser, webglRenderer: b.webglRenderer, count: b._count })),
      });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // CSV export
  app.get('/api/analytics/links/:trackingId/events/export', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const { limit = 5000 } = req.query;
      const events = await p.clickEvent.findMany({ where: { trackingId }, orderBy: { timestamp: 'desc' }, take: parseInt(limit) });
      const cols = ['id', 'timestamp', 'ipFull', 'country', 'region', 'city', 'isp', 'org', 'asn', 'deviceType', 'browser', 'browserVersion', 'os', 'osVersion', 'language', 'screenResolution', 'isVpn', 'isProxy', 'isTor', 'isBot', 'isHeadless', 'botScore', 'vpnScore', 'threatScore', 'webrtcLeakDetected', 'webrtcRealIp', 'fingerprintHash', 'userAgent', 'utmSource', 'utmMedium', 'utmCampaign'];
      const esc = v => v == null ? '' : ('"' + String(v).replace(/"/g, '""') + '"');
      const csv = [cols.join(','), ...events.map(e => cols.map(c => esc(e[c])).join(','))].join('\n');
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename = "events-${trackingId}.csv"`);
      res.send(csv);
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // Fingerprint events list (for detailed view)
  app.get('/api/links/:trackingId/fingerprint', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;
      const { limit = 20 } = req.query;

      const events = await p.clickEvent.findMany({
        where: { trackingId },
        orderBy: { timestamp: 'desc' },
        take: parseInt(limit),
        select: {
          id: true,
          timestamp: true,
          ipFull: true,
          ipTruncated: true,
          country: true,
          city: true,
          deviceType: true,
          deviceBrand: true,
          deviceModel: true,
          browser: true,
          os: true,
          screenResolution: true,
          viewportWidth: true,
          viewportHeight: true,
          fingerprintHash: true,
          visitorId: true,
          canvasFingerprintHash: true,
          webglFingerprintHash: true,
          webglVendor: true,
          webglRenderer: true,
          webgl2Enabled: true,
          audioFingerprint: true,
          fontsDetected: true,
          fontCount: true,
          isVpn: true,
          isProxy: true,
          isTor: true,
          isBot: true,
          isHeadless: true,
          threatScore: true,
          threatLevel: true,
          botScore: true,
          vpnScore: true,
          webrtcLeakDetected: true,
          webrtcRealIp: true,
          realIp: true,
          realIpDetected: true,
          batteryLevel: true,
          batteryCharging: true,
          humanScore: true,
          entropyScore: true,
          timeOnPage: true,
          scrollDepth: true,
          clickCount: true,
          keyCount: true,
          referrerDomain: true,
          language: true,
          userAgent: true,
          // GPS
          gpsGranted: true,
          gpsDenied: true,
          gpsLatitude: true,
          gpsLongitude: true,
          gpsAltitude: true,
          gpsAccuracy: true,
          gpsAltitudeAccuracy: true,
          gpsHeading: true,
          gpsSpeed: true,
          gpsAddress: true,
          // Sensors
          sensorGyroscope: true,
          sensorAccelerometer: true,
          sensorDeviceOrientation: true,
          sensorGravity: true,
          sensorMagnetometer: true,
          sensorAmbientLight: true,
          sensorsSupported: true,
          // Advanced
          speechVoicesHash: true,
          speechVoiceCount: true,
          mediaQueryHash: true,
          textMetricsHash: true,
          intlHash: true,
          clientHintsArchitecture: true,
          clientHintsBitness: true,
          clientHintsModel: true,
          clientHintsPlatform: true,
          clientHintsPlatformVersion: true,
          timerResolution: true,
          canvasNoise: true,
          uaSpoofScore: true,
          uaSpoofIndicators: true,
          isPrivacyBrowser: true,
          isVM: true,
          vmIndicators: true,
          // Extra location fields for display
          countryCode: true,
          region: true,
          district: true,
          neighborhood: true,
          zip: true,
          metroCode: true,
          latitude: true,
          longitude: true,
          accuracy: true,
          continent: true,
          timezoneOffset: true,
          timeZoneMismatch: true,
          // Network extra
          isp: true,
          org: true,
          asn: true,
          asname: true,
          carrier: true,
          reverseDns: true,
          domain: true,
          reputation: true,
          // Security extra
          isAutomated: true,
          isSelenium: true,
          isPuppeteer: true,
          isPlaywright: true,
          isPhantom: true,
          isCrawler: true,
          botIndicators: true,
          isBadActor: true,
          isAttacker: true,
          isAbuser: true,
          isThreat: true,
          detectionIndicators: true,
          // Device extra
          deviceVendor: true,
          maxTouchPoints: true,
          touchSupport: true,
          hardwareConcurrency: true,
          deviceMemory: true,
          colorDepth: true,
          pixelRatio: true,
          orientation: true,
          screenOrientation: true,
          // Canvas extra
          canvasFingerprintHash: true,
          canvasVariants: true,
          canvasGpuAccelerated: true,
          // WebGL extra
          webgl2Supported: true,
          webgl2Vendor: true,
          webgl2Renderer: true,
          webglShadingVersion: true,
          webglVersion: true,
          // Audio extra
          audioFingerprintHash: true,
          audioSampleRate: true,
          // Battery extra
          batterySupported: true,
          batteryChargingTime: true,
          batteryDischargingTime: true,
          // Network quality
          networkEffectiveType: true,
          networkDownlink: true,
          networkRtt: true,
          // Performance
          dnsTime: true,
          tcpTime: true,
          sslTime: true,
          ttfb: true,
          pageLoadTime: true,
          domInteractive: true,
          domComplete: true,
          // Browser
          browserEngine: true,
          // Identifiers
          sessionId: true,
          quantumHash: true,
          // Page
          pageUrl: true,
          pageDomain: true,
          pageTitle: true,
          // Misc
          isMobile: true,
          gpu: true,
          platform: true,
          webrtcRealCountry: true,
          vpnProvider: true,
          vpnType: true,
          bypassMethod: true,
          realIpCountry: true,
          realIpCity: true,
          realIpIsp: true,
          threatScore: true
        }
      });

      res.json(events);
    } catch (error) {
      console.error('Fingerprint events error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Fingerprint analysis (stats view)
  app.get('/api/analytics/links/:trackingId/fingerprints', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { trackingId } = req.params;

      const [
        uniqueVisitors,
        uniqueSessions,
        entropyAvg,
        humanScoreAvg,
        botScoreAvg,
        canvasFingerprints,
        webglFingerprints
      ] = await Promise.all([
        p.clickEvent.groupBy({
          by: ['visitorId'],
          where: { trackingId, visitorId: { not: null } },
          _count: true
        }),
        p.clickEvent.groupBy({
          by: ['sessionId'],
          where: { trackingId, sessionId: { not: null } },
          _count: true
        }),
        p.clickEvent.aggregate({
          where: { trackingId },
          _avg: { entropyScore: true }
        }),
        p.clickEvent.aggregate({
          where: { trackingId },
          _avg: { humanScore: true }
        }),
        p.clickEvent.aggregate({
          where: { trackingId },
          _avg: { botScore: true }
        }),
        p.clickEvent.groupBy({
          by: ['canvasFingerprintHash'],
          where: { trackingId, canvasFingerprintHash: { not: null } },
          _count: true,
          orderBy: { _count: { canvasFingerprintHash: 'desc' } },
          take: 20
        }),
        p.clickEvent.groupBy({
          by: ['webglFingerprintHash'],
          where: { trackingId, webglFingerprintHash: { not: null } },
          _count: true,
          orderBy: { _count: { webglFingerprintHash: 'desc' } },
          take: 20
        })
      ]);

      res.json({
        uniqueness: {
          uniqueVisitors: uniqueVisitors.length,
          uniqueSessions: uniqueSessions.length,
          avgEntropy: entropyAvg._avg.entropyScore
        },
        scores: {
          avgHumanScore: humanScoreAvg._avg.humanScore,
          avgBotScore: botScoreAvg._avg.botScore
        },
        fingerprints: {
          topCanvas: canvasFingerprints.map(f => ({ hash: f.canvasFingerprintHash, count: f._count })),
          topWebGL: webglFingerprints.map(f => ({ hash: f.webglFingerprintHash, count: f._count }))
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Porkbun domains list
  app.get('/api/porkbun/domains', requireAuth, async (req, res) => {
    try {
      const domains = await listAllDomains();
      res.json(domains);
    } catch (e) {
      if (e.message && e.message.includes('not configured')) {
        return res.json([]);
      }
      res.status(500).json({ error: e.message });
    }
  });

  // Domains endpoints
  app.get('/api/domains', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const domains = await p.customDomain.findMany({
        include: {
          link: {
            select: {
              trackingId: true,
              destinationUrl: true
            }
          }
        },
        orderBy: { createdAt: 'desc' }
      });

      res.json(domains.map(d => ({
        domain: d.domain,
        linkId: d.linkId,
        destinationUrl: d.link?.destinationUrl,
        isPrimary: d.isPrimary,
        sslEnabled: d.sslEnabled,
        createdAt: d.createdAt
      })));
    } catch (error) {
      console.error('Domains error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/links/:linkId/domains', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { linkId } = req.params;
      const { domain, isPrimary } = req.body;

      if (!domain || typeof domain !== 'string') {
        return res.status(400).json({ error: 'domain is required' });
      }

      const link = await p.link.findUnique({ where: { trackingId: linkId } });
      if (!link) {
        return res.status(404).json({ error: 'Link not found' });
      }

      const customDomain = await p.customDomain.create({
        data: {
          domain: domain.trim().toLowerCase(),
          linkId,
          isPrimary: isPrimary || false
        }
      });

      res.status(201).json(customDomain);
    } catch (error) {
      console.error('Add domain error:', error);
      if (error.code === 'P2002') {
        return res.status(409).json({ error: 'Domain already exists' });
      }
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/links/:linkId/domains/:domain', requireAuth, async (req, res) => {
    try {
      const p = getPrisma();
      const { domain } = req.params;

      await p.customDomain.delete({
        where: { domain: decodeURIComponent(domain).toLowerCase() }
      });

      res.status(204).send();
    } catch (error) {
      console.error('Delete domain error:', error);
      if (error.code === 'P2025') {
        return res.status(404).json({ error: 'Domain not found' });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Error handler
  app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal server error' });
  });

  return app;
}

// Utility functions
function truncateIp(ip) {
  if (!ip || ip === 'unknown') return 'unknown';
  if (ip.includes(':')) {
    const parts = ip.split(':');
    return parts.slice(0, 4).join(':') + '::';
  }
  const parts = ip.split('.');
  if (parts.length === 4) {
    return `${ parts[0] }.${ parts[1] }.${ parts[2] } .0`;
  }
  return ip;
}

function hashString(str) {
  return crypto.createHash('sha256').update(str).digest('hex').substring(0, 32);
}

function calculateBehaviorScore(behavior) {
  if (!behavior) return null;
  let score = 100;

  if (behavior.humanScore !== undefined) {
    score = behavior.humanScore;
  } else {
    if (!behavior.mouseMovements || behavior.mouseMovements.length < 5) score -= 20;
    if (behavior.clickCount === 0 && behavior.timeOnPage > 5000) score -= 15;
    if (behavior.scrollDepth < 10 && behavior.timeOnPage > 10000) score -= 10;
  }

  return Math.max(0, score);
}

function normalizeNetlifyPath(event) {
  const raw = (event.path || event.rawUrl || '').split('?')[0];
  const prefix = '/.netlify/functions/api';
  if (raw === prefix + '/click') {
    event.path = '/click';
  } else if (raw.startsWith(prefix + '/')) {
    event.path = '/api/' + raw.slice(prefix.length + 1);
  }
  return event;
}

export const handler = async (event, context) => {
  try {
    normalizeNetlifyPath(event);
    const application = getApp();
    const serverlessHandler = serverless(application);
    return await serverlessHandler(event, context);
  } catch (error) {
    console.error('Handler error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal server error', message: error.message })
    };
  }
};

export default handler;
